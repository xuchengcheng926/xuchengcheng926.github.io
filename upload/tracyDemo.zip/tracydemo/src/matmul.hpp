#pragma once

#include <condition_variable>
#include <cstddef>
#include <mutex>
#include <thread>
#include <vector>

namespace demo
{

// 行主序的 n x n 单精度矩阵。
struct Matrix
{
    std::size_t        n = 0;
    std::vector<float> data;

    Matrix() {}
    explicit Matrix( std::size_t dim ) : n( dim ), data( dim * dim, 0.0f ) {}

    float*       row( std::size_t r )       { return data.data() + r * n; }
    const float* row( std::size_t r ) const { return data.data() + r * n; }
};

struct Config
{
    std::size_t n       = 1024;  // 矩阵维度
    std::size_t block   = 64;    // 分块边长
    unsigned    threads = 0;     // 0 表示取 hardware_concurrency()
};

// 用 xorshift32 按固定种子填充，保证每次运行数据一致，便于横向对比。
void fill( Matrix& m, unsigned seed );

// 常驻线程池 + 分块矩阵乘法。
//
// 线程只在构造时创建一次，之后每次 run() 复用同一批线程，
// 这样在 profiler 里每一帧对应同一组线程行，便于逐帧比较。
//
// 同步用 mutex + condition_variable 的手写版本（C++11 可用），
// 没有用 C++20 的 std::barrier。
class MatmulEngine
{
public:
    MatmulEngine( const Matrix& a, const Matrix& b, Matrix& c, const Config& cfg );
    ~MatmulEngine();

    MatmulEngine( const MatmulEngine& ) = delete;
    MatmulEngine& operator=( const MatmulEngine& ) = delete;

    // 完成一次 c = a * b，返回时所有工作线程均已结束本轮。
    void run();

private:
    void worker_loop( unsigned tid );
    void compute_share( unsigned tid );

    const Matrix& a_;
    const Matrix& b_;
    Matrix&       c_;
    Config        cfg_;

    std::mutex              mutex_;
    std::condition_variable start_cv_;   // 主线程唤醒 worker
    std::condition_variable done_cv_;    // worker 通知主线程本轮结束
    std::size_t             generation_; // 已发令的轮次
    std::size_t             finished_;   // 本轮已完成的工作线程数
    bool                    quit_;

    std::vector<std::thread> workers_;
};

// 抽查若干元素与串行结果比对，返回最大相对误差。
double spot_check( const Matrix& a, const Matrix& b, const Matrix& c );

}  // namespace demo
