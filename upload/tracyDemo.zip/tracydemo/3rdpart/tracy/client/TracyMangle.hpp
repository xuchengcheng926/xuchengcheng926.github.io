#ifndef __TRACYMANGLE_HPP__
#define __TRACYMANGLE_HPP__

// TRACY_DELAYED_INIT is an internal implementation switch, not a user-facing
// option: Apple platforms require it, and TRACY_MANUAL_LIFETIME builds on top
// of it. It is derived here so that every translation unit, and the client
// implementation, see the same effective value before any config-dependent
// symbol name is computed.
#if defined(TRACY_MANUAL_LIFETIME) || defined(__APPLE__)
#  ifndef TRACY_DELAYED_INIT
#    define TRACY_DELAYED_INIT
#  endif
#endif

#ifdef TRACY_ENABLE
#define TRACY_ENABLE_MANGLE _E1
#else
#define TRACY_ENABLE_MANGLE _E0
#endif

#ifdef TRACY_ON_DEMAND
#define TRACY_ON_DEMAND_MANGLE _OD1
#else
#define TRACY_ON_DEMAND_MANGLE _OD0
#endif

#ifdef TRACY_DELAYED_INIT
#define TRACY_DELAYED_INIT_MANGLE _DI1
#else
#define TRACY_DELAYED_INIT_MANGLE _DI0
#endif

#ifdef TRACY_MANUAL_LIFETIME
#define TRACY_MANUAL_LIFETIME_MANGLE _ML1
#else
#define TRACY_MANUAL_LIFETIME_MANGLE _ML0
#endif

#ifdef TRACY_FIBERS
#define TRACY_FIBERS_MANGLE _F1
#else
#define TRACY_FIBERS_MANGLE _F0
#endif

#ifdef TRACY_DISALLOW_HW_TIMER
#define TRACY_DISALLOW_HW_TIMER_MANGLE _DHT1
#else
#define TRACY_DISALLOW_HW_TIMER_MANGLE _DHT0
#endif

#ifdef TRACY_TIMER_FALLBACK
#define TRACY_TIMER_FALLBACK_MANGLE _TF1
#else
#define TRACY_TIMER_FALLBACK_MANGLE _TF0
#endif

#ifdef TRACY_PLATFORM_HEADER
#define TRACY_PLATFORM_HEADER_MANGLE _PH1
#else
#define TRACY_PLATFORM_HEADER_MANGLE _PH0
#endif

#define MANGLED_NAME_BASED_ON_CONFIG(base) \
    TracyConcat(TracyConcat(TracyConcat(TracyConcat(TracyConcat(TracyConcat(TracyConcat(TracyConcat( \
    base##_CFG, \
    TRACY_ENABLE_MANGLE), \
    TRACY_ON_DEMAND_MANGLE), \
    TRACY_DELAYED_INIT_MANGLE), \
    TRACY_MANUAL_LIFETIME_MANGLE), \
    TRACY_FIBERS_MANGLE), \
    TRACY_DISALLOW_HW_TIMER_MANGLE), \
    TRACY_TIMER_FALLBACK_MANGLE), \
    TRACY_PLATFORM_HEADER_MANGLE)

#endif // __TRACYMANGLE_HPP__
