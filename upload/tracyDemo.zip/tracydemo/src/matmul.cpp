#include "matmul.hpp"

#include <tracy/Tracy.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>

namespace demo
{

namespace
{

// 计算 C[i0:i1, j0:j1] += A[i0:i1, k0:k1] * B[k0:k1, j0:j1]
//
// 采用 i-k-j 循环顺序：j 是最内层且连续，b 和 c 都是顺序访问，
// 只有 a 按行跳跃，这是分块乘法里对缓存最友好的顺序。
void tile_multiply( const Matrix& a, const Matrix& b, Matrix& c,
                    std::size_t i0, std::size_t i1,
                    std::size_t k0, std::size_t k1,
                    std::size_t j0, std::size_t j1 )
{
    ZoneScopedN( "tile" );

    for ( std::size_t i = i0; i < i1; ++i )
    {
        const float* arow = a.row( i );
        float*       crow = c.row( i );

        for ( std::size_t k = k0; k < k1; ++k )
        {
            const float  aik  = arow[k];
            const float* brow = b.row( k );

            for ( std::size_t j = j0; j < j1; ++j )
            {
                crow[j] += aik * brow[j];
            }
        }
    }
}

}  // namespace

void fill( Matrix& m, unsigned seed )
{
    ZoneScopedN( "fill" );

    std::uint32_t s = seed ? seed : 1u;
    for ( std::size_t i = 0; i < m.data.size(); ++i )
    {
        s ^= s << 13;
        s ^= s >> 17;
        s ^= s << 5;
        m.data[i] = static_cast<float>( s & 0xffffu ) / 65536.0f;
    }
}

MatmulEngine::MatmulEngine( const Matrix& a, const Matrix& b, Matrix& c, const Config& cfg )
    : a_( a )
    , b_( b )
    , c_( c )
    , cfg_( cfg )
    , generation_( 0 )
    , finished_( 0 )
    , quit_( false )
{
    workers_.reserve( cfg_.threads );
    for ( unsigned t = 0; t < cfg_.threads; ++t )
    {
        workers_.push_back( std::thread( &MatmulEngine::worker_loop, this, t ) );
    }
}

MatmulEngine::~MatmulEngine()
{
    {
        std::lock_guard<std::mutex> lock( mutex_ );
        quit_ = true;
    }
    start_cv_.notify_all();

    for ( std::size_t i = 0; i < workers_.size(); ++i )
    {
        if ( workers_[i].joinable() ) workers_[i].join();
    }
}

void MatmulEngine::run()
{
    ZoneScopedN( "matmul_blocked" );

    {
        std::lock_guard<std::mutex> lock( mutex_ );
        finished_ = 0;
        ++generation_;
    }
    start_cv_.notify_all();

    {
        std::unique_lock<std::mutex> lock( mutex_ );
        while ( finished_ != workers_.size() )
        {
            done_cv_.wait( lock );
        }
    }
}

void MatmulEngine::worker_loop( unsigned tid )
{
    const std::string name = "worker " + std::to_string( tid );
    tracy::SetThreadName( name.c_str() );

    std::size_t seen = 0;

    for ( ;; )
    {
        {
            std::unique_lock<std::mutex> lock( mutex_ );
            while ( !quit_ && generation_ == seen )
            {
                start_cv_.wait( lock );
            }
            if ( quit_ ) return;
            seen = generation_;
        }

        compute_share( tid );

        {
            std::lock_guard<std::mutex> lock( mutex_ );
            if ( ++finished_ == workers_.size() )
            {
                done_cv_.notify_one();
            }
        }
    }
}

void MatmulEngine::compute_share( unsigned tid )
{
    const std::size_t n      = cfg_.n;
    const std::size_t bs     = cfg_.block;
    const std::size_t blocks = ( n + bs - 1 ) / bs;

    // 静态划分：线程 tid 负责第 tid、tid+T、tid+2T …… 个 block row。
    for ( std::size_t bi = tid; bi < blocks; bi += cfg_.threads )
    {
        const std::size_t i0 = bi * bs;
        const std::size_t i1 = std::min( i0 + bs, n );

        ZoneScopedN( "block_row" );
        {
            // 把当前处理的行块编号写进 zone 名字，profiler 里能直接看到每个线程在算哪一块。
            char      label[64];
            const int len = std::snprintf( label, sizeof( label ), "row %lu/%lu",
                                           (unsigned long)bi, (unsigned long)blocks );
            ZoneName( label, static_cast<std::size_t>( len ) );
        }

        for ( std::size_t bk = 0; bk < blocks; ++bk )
        {
            const std::size_t k0 = bk * bs;
            const std::size_t k1 = std::min( k0 + bs, n );

            for ( std::size_t bj = 0; bj < blocks; ++bj )
            {
                const std::size_t j0 = bj * bs;
                const std::size_t j1 = std::min( j0 + bs, n );

                tile_multiply( a_, b_, c_, i0, i1, k0, k1, j0, j1 );
            }
        }
    }
}

double spot_check( const Matrix& a, const Matrix& b, const Matrix& c )
{
    ZoneScopedN( "spot_check" );

    const std::size_t n = c.n;
    if ( n == 0 ) return 0.0;

    const std::size_t samples = std::min<std::size_t>( 16, n );
    double            worst   = 0.0;

    for ( std::size_t s = 0; s < samples; ++s )
    {
        const std::size_t r   = ( s * 7919u ) % n;
        const std::size_t col = ( s * 104729u + 13u ) % n;

        // 双精度串行累加作为参照
        double acc = 0.0;
        for ( std::size_t k = 0; k < n; ++k )
        {
            acc += static_cast<double>( a.row( r )[k] ) * static_cast<double>( b.row( k )[col] );
        }

        const double got   = static_cast<double>( c.row( r )[col] );
        const double denom = std::max( 1.0, std::fabs( acc ) );
        worst              = std::max( worst, std::fabs( acc - got ) / denom );
    }

    return worst;
}

}  // namespace demo
