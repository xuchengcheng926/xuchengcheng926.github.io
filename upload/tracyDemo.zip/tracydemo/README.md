# Tracy 矩阵乘法插桩 demo

一个用于练手 Tracy Profiler 的小程序：多线程分块矩阵乘法，用 Tracy 打了 zone、帧标记和曲线图。

## 编译

```bash
cd demo
cmake -B build -S .
cmake --build build
```

产物直接输出到 `build/matmul_demo`。默认构建类型是 `RelWithDebInfo`（`-O2 -g`）：优化后的耗时才有意义，调试符号则让 profiler 能显示函数名和源码行。

CMake 里把 Tracy 客户端单独编成了一个静态库，并对它使用了 `SYSTEM` 头文件目录和 `-w`，因此 Tracy 自身代码的警告不会出现在你的构建日志里。

## 运行

```bash
# 终端 1：启动 profiler
./tool/tracy-profiler

# 终端 2：启动 demo,开启sudo可以trace系统级信息(线程调度信息)
sudo ./build/matmul_demo
```

profiler 会自动发现本机的 Tracy 客户端（默认监听 8086 端口并广播）。若没自动发现，在 profiler 里手动填 `127.0.0.1` 连接。

连上之后按 profiler 界面上的保存按钮可以存成 `.tracy` 文件，之后能离线加载，也能用 `tracy-csvexport` 导出成 CSV。

