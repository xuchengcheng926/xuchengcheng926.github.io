#include "matmul.hpp"

#include <tracy/Tracy.hpp>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>

namespace
{

void usage( const char* argv0 )
{
    std::printf(
        "用法: %s [选项]\n"
        "  --n <dim>         矩阵维度 n（n x n），默认 1024\n"
        "  --block <size>    分块边长，默认 64\n"
        "  --threads <num>   工作线程数，默认 hardware_concurrency\n"
        "  --no-verify       跳过首帧之后的正确性抽查\n"
        "  --help            显示本帮助\n"
        "\n"
        "程序会一直循环计算，不主动退出，按 Ctrl+C 结束。\n",
        argv0 );
}

}  // namespace

int main( int argc, char** argv )
{
    tracy::SetThreadName( "main" );

    demo::Config cfg;
    bool         verify = true;

    for ( int i = 1; i < argc; ++i )
    {
        const char* arg   = argv[i];
        const char* value = argv[i + 1];   // argv[argc] 保证为 NULL

        if ( std::strcmp( arg, "--help" ) == 0 )
        {
            usage( argv[0] );
            return 0;
        }
        else if ( std::strcmp( arg, "--n" ) == 0 && value != 0 )
        {
            cfg.n = std::strtoull( value, 0, 10 );
            ++i;
        }
        else if ( std::strcmp( arg, "--block" ) == 0 && value != 0 )
        {
            cfg.block = std::strtoull( value, 0, 10 );
            ++i;
        }
        else if ( std::strcmp( arg, "--threads" ) == 0 && value != 0 )
        {
            cfg.threads = static_cast<unsigned>( std::strtoul( value, 0, 10 ) );
            ++i;
        }
        else if ( std::strcmp( arg, "--no-verify" ) == 0 )
        {
            verify = false;
        }
        else
        {
            std::fprintf( stderr, "未知参数: %s\n", arg );
            usage( argv[0] );
            return 1;
        }
    }

    if ( cfg.n == 0 ) cfg.n = 1;
    if ( cfg.block == 0 ) cfg.block = 64;
    if ( cfg.threads == 0 )
        cfg.threads = std::min( 4u, std::thread::hardware_concurrency() );

    std::printf( "=== Tracy 矩阵乘法 demo ===\n" );
    std::printf( "n=%lu  分块=%lu  线程=%u\n",
                 static_cast<unsigned long>( cfg.n ),
                 static_cast<unsigned long>( cfg.block ),
                 cfg.threads );
    std::printf( "循环运行中，按 Ctrl+C 结束\n\n" );

    {
        char      msg[160];
        const int len = std::snprintf( msg, sizeof( msg ), "n=%lu block=%lu threads=%u",
                                       static_cast<unsigned long>( cfg.n ),
                                       static_cast<unsigned long>( cfg.block ),
                                       cfg.threads );
        TracyMessageL( "tracy matmul demo start" );
        TracyMessage( msg, static_cast<std::size_t>( len ) );
    }

    TracyPlotConfig( "frame ms", tracy::PlotFormatType::Number, false, true, 0xff8888ffu );
    TracyPlotConfig( "GFLOPS", tracy::PlotFormatType::Number, false, true, 0xff88ff88u );

    demo::Matrix a( cfg.n ), b( cfg.n ), c( cfg.n );

    {
        ZoneScopedN( "prepare" );
        demo::fill( a, 0x12345678u );
        demo::fill( b, 0x9abcdef0u );
    }

    const double flop = 2.0 * static_cast<double>( cfg.n )
                            * static_cast<double>( cfg.n )
                            * static_cast<double>( cfg.n );

    demo::MatmulEngine engine( a, b, c, cfg );   // 工作线程只在此处创建一次

    unsigned long long frame = 0;
    bool               first = true;

    for ( ;; )
    {
        // 清零不计入测量，但会让下一轮从冷缓存开始。
        std::fill( c.data.begin(), c.data.end(), 0.0f );

        const auto t0 = std::chrono::steady_clock::now();
        engine.run();
        const auto t1 = std::chrono::steady_clock::now();

        const double ms     = std::chrono::duration<double, std::milli>( t1 - t0 ).count();
        const double gflops = flop / ( ms * 1.0e6 );

        TracyPlot( "frame ms", ms );
        TracyPlot( "GFLOPS", gflops );
        FrameMark;

        std::printf( "frame %6llu: %8.2f ms  %8.2f GFLOPS\n", frame, ms, gflops );

        if ( first )
        {
            first = false;
            if ( verify )
            {
                const double err = demo::spot_check( a, b, c );
                std::printf( "  抽查最大相对误差: %.3e\n", err );
                if ( err > 1.0e-3 )
                {
                    std::printf( "  !! 误差偏大，结果可能有误\n" );
                }
            }
        }

        ++frame;
    }
}
